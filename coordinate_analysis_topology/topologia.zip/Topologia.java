package com.stormadvance.kafka_storm_topology;

import org.apache.storm.Config;
import org.apache.storm.LocalCluster;
import org.apache.storm.StormSubmitter;
import org.apache.storm.topology.TopologyBuilder;

public class Topologia {

	public static void main(String[] args) throws Exception {
		
		TopologyBuilder builder = new TopologyBuilder();
        builder.setSpout("KafkaSpout", new KafkaConsumerSpout());
        builder.setBolt("AnalyseBolt", new AnalyseBolt(), 12).shuffleGrouping("KafkaSpout");
        builder.setBolt("SendBolt", new SendBolt(), 12).shuffleGrouping("AnalyseBolt").setNumTasks(4);

        boolean producao = true;
        
        Config conf = new Config();
        conf.setNumWorkers(3);
        conf.setDebug(!producao);
        
        if(producao) {
	        conf.put("caminho_shape", "/home/administrador/shape_pistas/pistas_pouso_4326.shp");
	        StormSubmitter.submitTopology("kafkaTopology", conf, builder.createTopology());
        } else {
        	conf.put("caminho_shape", "pistas_pouso_4326.shp");
	        LocalCluster cluster = new LocalCluster();
	        cluster.submitTopology("kafkaTopology", conf, builder.createTopology());
	        Thread.sleep(1200*1000);
	        cluster.shutdown();
        }
	}

}
